CANVAS COURSE CLEANUP
=====================

What it does
------------

This program handles two repetitive Canvas jobs:

1. Converts assignments with "Video" in the title into Canvas pages containing
   the saved external video link. It creates and verifies the page before it
   changes the original assignment. The original is then changed to Not Graded,
   unpublished, and moved to the unused module you select.

2. Finds other unpublished module items. Assignments, graded quizzes, and graded
   discussions are changed to Not Graded before being moved. Other unpublished
   items are moved without an unnecessary grading change.

The program skips the selected unused module, so it can safely be run again on a
partly completed course. It never stores your Canvas token.


Before the first run
--------------------

1. Extract this entire folder. Do not run the program from inside the ZIP file.
2. Keep the folder somewhere easy to identify. A sensible permanent location is:

   OneDrive\02_SY2026_2027\Pathway Design\General Items\Canvas Course Cleanup

3. You need Python 3 on the computer. The Python installation used for your
   course or VS Code is sufficient.
4. Your Canvas token may have a maximum 30-day expiration. That is fine. If it
   expires, generate a new token; the program itself does not need to change.


Starting the program on Windows
-------------------------------

Double-click:

   Start_Canvas_Cleanup.bat

If Windows asks what should open Python files, select your Python 3 installation.
You can also open Canvas_Course_Cleanup.py in VS Code and choose Run Python File.


Using the program
-----------------

1. Leave the Canvas address as https://learn3.k12.com.
2. Paste the access token into the concealed Access token box.
3. Select Connect.
4. Select the course by name. The program will load that course's modules.
5. Select the existing unused/archive module. It must be unpublished.
6. Leave both cleanup options checked and leave the video title word as Video.
7. Leave First-run test mode checked. This limits the first preview and run to
   one item so you can verify the result in Canvas before processing everything.
8. Select 1. Preview Course.
9. Read the counts and the Needs Attention section. The preview does not change
   Canvas. It also saves every captured video link in a dated backup report.
10. If the course and unused module are correct, select 2. Run Approved Plan and
   confirm the warning.
11. Review the result list and then refresh the Canvas Modules and Grades pages.
12. Once the first item is correct, turn off First-run test mode, create a new
    preview for the remaining course, and run that approved plan.

Run the first test on one course while it has no students. The program processes
each item independently. If Canvas rejects one item, the program records the
error and continues with the others.


Safety behavior
---------------

- The token is held only in memory and disappears when the program closes.
- Preview and result reports are stored in Canvas_Cleanup_Reports inside this
  folder. They never contain the Canvas token.
- A video assignment is not changed until the replacement page exists and the
  exact external URL has been verified.
- If page creation fails, the original assignment remains untouched.
- If the same-title page already exists and contains the correct link, the
  program reuses it. This lets it resume a partially completed conversion.
- The program refuses to run when the selected unused module is published.
- Items it cannot identify safely are listed under Needs Attention and skipped.


Stopping or rerunning
---------------------

If the computer, network, or Canvas interrupts the run, open the program again
and create a new preview. Completed items in the unused module are skipped.
Verified replacement pages can be reused to finish an interrupted conversion.

Do not share the token in email, screenshots, or chat. When its 30-day period
ends, create a replacement token through Canvas Account > Settings > Approved
Integrations.
