@echo off
setlocal
cd /d "%~dp0"
where pyw >nul 2>nul
if %errorlevel%==0 (
    start "" pyw -3 "Canvas_Course_Cleanup.py"
    exit /b 0
)
where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "Canvas_Course_Cleanup.py"
    exit /b 0
)
echo Python 3 was not found by the Windows launcher.
echo Open Canvas_Course_Cleanup.py in VS Code and choose Run Python File.
pause

