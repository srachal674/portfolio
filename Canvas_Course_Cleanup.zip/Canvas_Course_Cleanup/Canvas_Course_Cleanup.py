#!/usr/bin/env python3
"""Canvas Course Cleanup

A small, local desktop tool for two repetitive Canvas course-maintenance jobs:

1. Convert external-tool video assignments into ordinary Canvas pages while
   preserving the external link, module position, indentation, and publication
   state. The original assignment is made not graded, unpublished, and moved to
   a selected unused/archive module only after the replacement page is verified.
2. Make other unpublished assignments not graded and move unpublished module
   items into the selected unused/archive module.

The access token is held in memory only. It is never written to disk.
"""

from __future__ import annotations

import html
import json
import queue
import re
import ssl
import sys
import threading
import traceback
from dataclasses import asdict, dataclass, field
from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen


APP_NAME = "Canvas Course Cleanup"
APP_VERSION = "1.0.0"
DEFAULT_CANVAS_URL = "https://learn3.k12.com"
REPORT_DIRECTORY = "Canvas_Cleanup_Reports"


class CanvasAPIError(RuntimeError):
    """A readable Canvas API error with the HTTP status when available."""

    def __init__(self, message: str, status: Optional[int] = None):
        super().__init__(message)
        self.status = status


def normalize_canvas_base_url(value: str) -> str:
    """Accept a Canvas home/course/API URL and return only scheme + host."""

    raw = value.strip()
    if not raw:
        raise ValueError("Enter the Canvas address.")
    if "://" not in raw:
        raw = "https://" + raw
    parts = urlsplit(raw)
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        raise ValueError("Enter a valid Canvas address, such as https://learn3.k12.com")
    return urlunsplit((parts.scheme, parts.netloc, "", "", "")).rstrip("/")


def _canvas_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _flatten_params(values: Optional[dict[str, Any]]) -> list[tuple[str, str]]:
    flattened: list[tuple[str, str]] = []
    for key, value in (values or {}).items():
        if value is None:
            continue
        if isinstance(value, (list, tuple)):
            flattened.extend((key, _canvas_value(item)) for item in value)
        else:
            flattened.append((key, _canvas_value(value)))
    return flattened


class CanvasAPI:
    """Minimal standard-library Canvas REST client with pagination."""

    def __init__(self, base_url: str, token: str, timeout: int = 45):
        self.base_url = normalize_canvas_base_url(base_url)
        self.api_root = self.base_url + "/api/v1"
        self.token = token.strip()
        self.timeout = timeout
        if not self.token:
            raise ValueError("Enter the Canvas access token.")

    def _request_url(
        self,
        method: str,
        url: str,
        *,
        params: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
    ) -> tuple[Any, dict[str, str]]:
        query = urlencode(_flatten_params(params))
        if query:
            url += ("&" if "?" in url else "?") + query
        payload = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "User-Agent": f"{APP_NAME}/{APP_VERSION}",
        }
        if data is not None:
            payload = urlencode(_flatten_params(data)).encode("utf-8")
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        request = Request(url, data=payload, headers=headers, method=method.upper())
        try:
            with urlopen(request, timeout=self.timeout, context=ssl.create_default_context()) as response:
                raw = response.read().decode("utf-8")
                parsed = json.loads(raw) if raw.strip() else {}
                return parsed, {key.lower(): value for key, value in response.headers.items()}
        except HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            detail = raw
            try:
                body = json.loads(raw)
                detail = self._error_text(body)
            except (ValueError, TypeError):
                pass
            if exc.code == 401:
                detail = "Canvas rejected the token. Check that it is active and copied completely."
            elif exc.code == 403:
                detail = "Canvas says this account does not have permission for that change."
            raise CanvasAPIError(f"Canvas error {exc.code}: {detail}", exc.code) from exc
        except URLError as exc:
            raise CanvasAPIError(f"Could not connect to Canvas: {exc.reason}") from exc

    @staticmethod
    def _error_text(body: Any) -> str:
        if isinstance(body, dict):
            if isinstance(body.get("message"), str):
                return body["message"]
            errors = body.get("errors")
            if isinstance(errors, list):
                messages = []
                for entry in errors:
                    if isinstance(entry, dict):
                        messages.append(str(entry.get("message") or entry))
                    else:
                        messages.append(str(entry))
                if messages:
                    return "; ".join(messages)
            return json.dumps(body, ensure_ascii=False)
        return str(body)

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
    ) -> Any:
        url = path if path.startswith("http") else self.api_root + path
        result, _headers = self._request_url(method, url, params=params, data=data)
        return result

    def get(self, path: str, params: Optional[dict[str, Any]] = None) -> Any:
        return self.request("GET", path, params=params)

    def post(self, path: str, data: Optional[dict[str, Any]] = None) -> Any:
        return self.request("POST", path, data=data)

    def put(self, path: str, data: Optional[dict[str, Any]] = None) -> Any:
        return self.request("PUT", path, data=data)

    def delete(self, path: str) -> Any:
        return self.request("DELETE", path)

    def get_all(self, path: str, params: Optional[dict[str, Any]] = None) -> list[Any]:
        url = path if path.startswith("http") else self.api_root + path
        first_params = dict(params or {})
        first_params.setdefault("per_page", 100)
        results: list[Any] = []
        while url:
            page, headers = self._request_url("GET", url, params=first_params)
            first_params = {}
            if not isinstance(page, list):
                raise CanvasAPIError("Canvas returned an unexpected response while listing content.")
            results.extend(page)
            url = self._next_link(headers.get("link", ""))
        return results

    @staticmethod
    def _next_link(link_header: str) -> Optional[str]:
        for target, relation in re.findall(r'<([^>]+)>;\s*rel="([^"]+)"', link_header):
            if relation == "next":
                return target
        return None


class _LinkCollector(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        if tag.lower() != "a":
            return
        for key, value in attrs:
            if key.lower() == "href" and value:
                self.links.append(html.unescape(value.strip()))


def extract_links(markup: Optional[str]) -> list[str]:
    if not markup:
        return []
    parser = _LinkCollector()
    try:
        parser.feed(markup)
    except Exception:
        return []
    return parser.links


def extract_external_tool_url(assignment: dict[str, Any]) -> Optional[str]:
    attributes = assignment.get("external_tool_tag_attributes") or {}
    if isinstance(attributes, dict):
        value = attributes.get("url")
        if isinstance(value, str) and value.strip():
            return html.unescape(value.strip())
    # A few imported course shells put the launch link in the description.
    for link in extract_links(assignment.get("description")):
        if link.startswith(("http://", "https://")):
            return link
    return None


def extract_page_external_url(page: dict[str, Any]) -> Optional[str]:
    links = extract_links(page.get("body"))
    return links[0] if links else None


def video_title_matches(title: str, phrase: str) -> bool:
    needle = phrase.strip()
    if not needle:
        return False
    return re.search(rf"(?i)(?<!\w){re.escape(needle)}(?!\w)", title or "") is not None


def safe_assignment_snapshot(assignment: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "id",
        "name",
        "description",
        "published",
        "workflow_state",
        "grading_type",
        "points_possible",
        "submission_types",
        "external_tool_tag_attributes",
        "due_at",
        "unlock_at",
        "lock_at",
        "assignment_group_id",
        "frozen",
        "frozen_attributes",
    )
    return {key: assignment.get(key) for key in keys if key in assignment}


@dataclass
class CleanupAction:
    kind: str
    title: str
    source_module_id: int
    source_module_name: str
    item_id: int
    item_type: str
    content_id: Optional[int]
    position: int
    indent: int
    published: bool
    assignment_id: Optional[int] = None
    external_url: Optional[str] = None
    existing_page_url: Optional[str] = None
    existing_page_item_id: Optional[int] = None
    snapshot: dict[str, Any] = field(default_factory=dict)

    def description(self) -> str:
        if self.kind == "convert_video":
            label = "CONVERT VIDEO TO PAGE"
        elif self.assignment_id:
            label = "MAKE NOT GRADED + MOVE"
        else:
            label = "MOVE UNPUBLISHED ITEM"
        return f"{label}: {self.source_module_name}  >  {self.title}"


@dataclass
class CleanupPlan:
    created_at: str
    canvas_url: str
    course_id: int
    course_name: str
    archive_module_id: int
    archive_module_name: str
    video_phrase: str
    convert_videos: bool
    archive_unpublished: bool
    actions: list[CleanupAction] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "CleanupPlan":
        actions = [CleanupAction(**action) for action in value.pop("actions", [])]
        return cls(actions=actions, **value)


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def slug_for_filename(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._")
    return value[:80] or "course"


def report_folder() -> Path:
    location = Path(__file__).resolve().parent / REPORT_DIRECTORY
    location.mkdir(parents=True, exist_ok=True)
    return location


def save_json_report(prefix: str, course_name: str, data: Any) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{prefix}_{slug_for_filename(course_name)}_{timestamp}.json"
    path = report_folder() / filename
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
    temporary.replace(path)
    return path


ProgressCallback = Callable[[str], None]


class CleanupEngine:
    def __init__(self, api: CanvasAPI, progress: Optional[ProgressCallback] = None):
        self.api = api
        self.progress = progress or (lambda _message: None)

    def list_courses(self) -> list[dict[str, Any]]:
        self.progress("Loading the courses you can teach…")
        courses = self.api.get_all(
            "/courses",
            {
                "enrollment_type": "teacher",
                "include[]": ["term"],
            },
        )
        courses = [course for course in courses if course.get("id") and course.get("name")]
        courses.sort(key=lambda course: (self._term_name(course).lower(), course["name"].lower()))
        return courses

    @staticmethod
    def _term_name(course: dict[str, Any]) -> str:
        term = course.get("term") or {}
        return str(term.get("name") or "No term listed")

    @classmethod
    def course_display_name(cls, course: dict[str, Any]) -> str:
        return f"{course.get('name')}  —  {cls._term_name(course)}  (ID {course.get('id')})"

    def list_modules(self, course_id: int) -> list[dict[str, Any]]:
        self.progress("Loading course modules…")
        modules = self.api.get_all(f"/courses/{course_id}/modules")
        modules.sort(key=lambda module: int(module.get("position") or 0))
        return modules

    def _list_module_items(self, course_id: int, module_id: int) -> list[dict[str, Any]]:
        return self.api.get_all(
            f"/courses/{course_id}/modules/{module_id}/items",
            {"include[]": ["content_details"]},
        )

    def _get_assignment(self, course_id: int, assignment_id: int) -> dict[str, Any]:
        result = self.api.get(f"/courses/{course_id}/assignments/{assignment_id}")
        if not isinstance(result, dict):
            raise CanvasAPIError("Canvas returned an unexpected assignment response.")
        return result

    def _get_page(self, course_id: int, page_url: str) -> dict[str, Any]:
        result = self.api.get(f"/courses/{course_id}/pages/{quote(str(page_url), safe='')}")
        if not isinstance(result, dict):
            raise CanvasAPIError("Canvas returned an unexpected page response.")
        return result

    def _linked_assignment_id(
        self, course_id: int, item: dict[str, Any]
    ) -> tuple[Optional[int], dict[str, Any]]:
        item_type = item.get("type")
        content_id = item.get("content_id")
        if item_type == "Assignment" and content_id:
            assignment = self._get_assignment(course_id, int(content_id))
            return int(content_id), safe_assignment_snapshot(assignment)
        if item_type == "Quiz" and content_id:
            quiz = self.api.get(f"/courses/{course_id}/quizzes/{content_id}")
            assignment_id = quiz.get("assignment_id") if isinstance(quiz, dict) else None
            if assignment_id:
                assignment = self._get_assignment(course_id, int(assignment_id))
                return int(assignment_id), safe_assignment_snapshot(assignment)
            return None, {"quiz": quiz}
        if item_type == "Discussion" and content_id:
            topic = self.api.get(f"/courses/{course_id}/discussion_topics/{content_id}")
            assignment_id = topic.get("assignment_id") if isinstance(topic, dict) else None
            if assignment_id:
                assignment = self._get_assignment(course_id, int(assignment_id))
                return int(assignment_id), safe_assignment_snapshot(assignment)
            return None, {"discussion": topic}
        return None, {}

    def build_plan(
        self,
        *,
        course: dict[str, Any],
        modules: list[dict[str, Any]],
        archive_module: dict[str, Any],
        video_phrase: str = "video",
        convert_videos: bool = True,
        archive_unpublished: bool = True,
    ) -> CleanupPlan:
        course_id = int(course["id"])
        archive_module_id = int(archive_module["id"])
        plan = CleanupPlan(
            created_at=now_iso(),
            canvas_url=self.api.base_url,
            course_id=course_id,
            course_name=str(course.get("name") or course_id),
            archive_module_id=archive_module_id,
            archive_module_name=str(archive_module.get("name") or archive_module_id),
            video_phrase=video_phrase.strip() or "video",
            convert_videos=convert_videos,
            archive_unpublished=archive_unpublished,
        )

        if bool(archive_module.get("published")):
            plan.issues.append(
                f"BLOCKING: The destination module '{plan.archive_module_name}' is published. "
                "Unpublish that module before running cleanup."
            )

        seen_content: set[tuple[str, int]] = set()
        for index, module in enumerate(modules, start=1):
            module_id = int(module["id"])
            if module_id == archive_module_id:
                continue
            module_name = str(module.get("name") or module_id)
            self.progress(f"Scanning module {index} of {len(modules)}: {module_name}")
            try:
                items = self._list_module_items(course_id, module_id)
            except Exception as exc:
                plan.issues.append(f"Could not scan module '{module_name}': {exc}")
                continue

            page_items_by_title: dict[str, list[dict[str, Any]]] = {}
            for item in items:
                if item.get("type") == "Page":
                    page_items_by_title.setdefault(str(item.get("title") or "").casefold(), []).append(item)

            for item in items:
                title = str(item.get("title") or "Untitled item")
                item_type = str(item.get("type") or "Unknown")
                item_id = int(item.get("id") or 0)
                content_id = item.get("content_id")
                numeric_content_id = int(content_id) if content_id is not None else None
                base = dict(
                    title=title,
                    source_module_id=module_id,
                    source_module_name=module_name,
                    item_id=item_id,
                    item_type=item_type,
                    content_id=numeric_content_id,
                    position=int(item.get("position") or 1),
                    indent=int(item.get("indent") or 0),
                    published=bool(item.get("published", False)),
                )

                is_video_assignment = (
                    convert_videos
                    and item_type == "Assignment"
                    and numeric_content_id is not None
                    and video_title_matches(title, plan.video_phrase)
                )
                if is_video_assignment:
                    key = (item_type, numeric_content_id)
                    if key in seen_content:
                        plan.issues.append(
                            f"Skipped duplicate module reference for video assignment '{title}' in '{module_name}'."
                        )
                        continue
                    seen_content.add(key)
                    try:
                        assignment = self._get_assignment(course_id, numeric_content_id)
                        external_url = extract_external_tool_url(assignment)
                        matching_pages = page_items_by_title.get(title.casefold(), [])
                        existing_page_url = None
                        existing_page_item_id = None
                        if len(matching_pages) > 1:
                            plan.issues.append(
                                f"Skipped '{title}' in '{module_name}': more than one same-title page already exists."
                            )
                            continue
                        if matching_pages:
                            page_item = matching_pages[0]
                            page = self._get_page(course_id, str(page_item.get("page_url")))
                            page_link = extract_page_external_url(page)
                            if external_url and page_link and page_link != external_url:
                                plan.issues.append(
                                    f"Skipped '{title}' in '{module_name}': the existing page contains a different link."
                                )
                                continue
                            external_url = external_url or page_link
                            existing_page_url = str(page_item.get("page_url"))
                            existing_page_item_id = int(page_item.get("id"))
                        if not external_url:
                            plan.issues.append(
                                f"Skipped video assignment '{title}' in '{module_name}': no external link was found."
                            )
                            continue
                        plan.actions.append(
                            CleanupAction(
                                kind="convert_video",
                                assignment_id=numeric_content_id,
                                external_url=external_url,
                                existing_page_url=existing_page_url,
                                existing_page_item_id=existing_page_item_id,
                                snapshot=safe_assignment_snapshot(assignment),
                                **base,
                            )
                        )
                    except Exception as exc:
                        plan.issues.append(f"Skipped video assignment '{title}': {exc}")
                    continue

                if not archive_unpublished or item.get("published") is not False:
                    continue

                key = (item_type, numeric_content_id or item_id)
                if key in seen_content and item_type in {"Assignment", "Quiz", "Discussion"}:
                    plan.issues.append(
                        f"Skipped duplicate module reference '{title}' in '{module_name}'."
                    )
                    continue
                seen_content.add(key)
                try:
                    assignment_id, snapshot = self._linked_assignment_id(course_id, item)
                    plan.actions.append(
                        CleanupAction(
                            kind="archive_unpublished",
                            assignment_id=assignment_id,
                            snapshot=snapshot,
                            **base,
                        )
                    )
                except Exception as exc:
                    plan.issues.append(f"Skipped unpublished item '{title}' in '{module_name}': {exc}")

        return plan

    def execute_plan(self, plan: CleanupPlan) -> dict[str, Any]:
        if any(issue.startswith("BLOCKING:") for issue in plan.issues):
            raise CanvasAPIError("The plan has a blocking issue. Fix it and create a new preview.")
        results: list[dict[str, Any]] = []
        for index, action in enumerate(plan.actions, start=1):
            self.progress(f"Running {index} of {len(plan.actions)}: {action.title}")
            result = {
                "title": action.title,
                "kind": action.kind,
                "source_module": action.source_module_name,
                "started_at": now_iso(),
            }
            try:
                if action.kind == "convert_video":
                    detail = self._execute_video_conversion(plan, action)
                else:
                    detail = self._execute_archive(plan, action)
                result.update(status="completed", detail=detail, finished_at=now_iso())
            except Exception as exc:
                result.update(status="failed", error=str(exc), finished_at=now_iso())
            results.append(result)
        return {
            "app": APP_NAME,
            "version": APP_VERSION,
            "course_id": plan.course_id,
            "course_name": plan.course_name,
            "archive_module_id": plan.archive_module_id,
            "archive_module_name": plan.archive_module_name,
            "started_from_plan": plan.created_at,
            "finished_at": now_iso(),
            "results": results,
        }

    def _update_assignment_not_graded(self, course_id: int, assignment_id: int) -> dict[str, Any]:
        updated = self.api.put(
            f"/courses/{course_id}/assignments/{assignment_id}",
            {
                "assignment[grading_type]": "not_graded",
                "assignment[published]": False,
                "assignment[notify_of_update]": False,
            },
        )
        if not isinstance(updated, dict) or updated.get("grading_type") != "not_graded":
            raise CanvasAPIError("Canvas did not confirm that the assignment is Not Graded.")
        return updated

    def _move_item(self, plan: CleanupPlan, action: CleanupAction) -> dict[str, Any]:
        moved = self.api.put(
            f"/courses/{plan.course_id}/modules/{action.source_module_id}/items/{action.item_id}",
            {
                "module_item[module_id]": plan.archive_module_id,
                "module_item[published]": False,
            },
        )
        if not isinstance(moved, dict) or int(moved.get("module_id") or 0) != plan.archive_module_id:
            raise CanvasAPIError("Canvas did not confirm that the item reached the unused module.")
        return moved

    def _execute_archive(self, plan: CleanupPlan, action: CleanupAction) -> str:
        if action.assignment_id:
            self._update_assignment_not_graded(plan.course_id, int(action.assignment_id))
        self._move_item(plan, action)
        if action.assignment_id:
            return "Changed to Not Graded, unpublished, and moved to the unused module."
        return "Moved the unpublished item to the unused module."

    @staticmethod
    def _page_body(title: str, external_url: str) -> str:
        escaped_url = html.escape(external_url, quote=True)
        escaped_title = html.escape(title)
        return (
            f'<p><a href="{escaped_url}" target="_blank" rel="noopener">'
            f"Watch {escaped_title}</a></p>"
        )

    def _verify_page_link(self, course_id: int, page_url: str, expected_url: str) -> dict[str, Any]:
        page = self._get_page(course_id, page_url)
        links = extract_links(page.get("body"))
        if expected_url not in links:
            raise CanvasAPIError("The replacement page was created, but its external link did not verify.")
        return page

    def _execute_video_conversion(self, plan: CleanupPlan, action: CleanupAction) -> str:
        if not action.assignment_id or not action.external_url:
            raise CanvasAPIError("The saved video information is incomplete; the original was left untouched.")

        assignment = self._get_assignment(plan.course_id, int(action.assignment_id))
        live_url = extract_external_tool_url(assignment)
        if live_url and live_url != action.external_url:
            raise CanvasAPIError("The assignment link changed after preview; the original was left untouched.")

        page_url = action.existing_page_url
        created_page_url: Optional[str] = None
        if page_url:
            self._verify_page_link(plan.course_id, page_url, action.external_url)
        else:
            page = self.api.post(
                f"/courses/{plan.course_id}/pages",
                {
                    "wiki_page[title]": action.title,
                    "wiki_page[body]": self._page_body(action.title, action.external_url),
                    "wiki_page[published]": action.published,
                    "wiki_page[notify_of_update]": False,
                },
            )
            if not isinstance(page, dict) or not page.get("url"):
                raise CanvasAPIError("Canvas did not return the new page address; the original was left untouched.")
            page_url = str(page["url"])
            created_page_url = page_url
            try:
                new_item = self.api.post(
                    f"/courses/{plan.course_id}/modules/{action.source_module_id}/items",
                    {
                        "module_item[type]": "Page",
                        "module_item[page_url]": page_url,
                        "module_item[position]": action.position,
                        "module_item[indent]": action.indent,
                    },
                )
                if not isinstance(new_item, dict) or new_item.get("type") != "Page":
                    raise CanvasAPIError("Canvas did not confirm the replacement page in the module.")
            except Exception:
                # This page was created by this operation and is not referenced by
                # a module, so removing it is a safe rollback.
                try:
                    self.api.delete(
                        f"/courses/{plan.course_id}/pages/{quote(created_page_url, safe='')}"
                    )
                except Exception:
                    pass
                raise
            self._verify_page_link(plan.course_id, page_url, action.external_url)

        # This is intentionally last. Canvas can remove the external-tool URL
        # when an assignment becomes Not Graded.
        self._update_assignment_not_graded(plan.course_id, int(action.assignment_id))
        self._move_item(plan, action)
        return "Verified the new linked page, then made the original Not Graded and moved it."


def plan_summary(plan: CleanupPlan) -> str:
    video_count = sum(action.kind == "convert_video" for action in plan.actions)
    assignment_count = sum(
        action.kind != "convert_video" and bool(action.assignment_id) for action in plan.actions
    )
    item_count = sum(
        action.kind != "convert_video" and not action.assignment_id for action in plan.actions
    )
    lines = [
        "PREVIEW — Canvas has not been changed",
        "",
        f"Course: {plan.course_name}",
        f"Unused module: {plan.archive_module_name}",
        "",
        f"Video assignments to convert: {video_count}",
        f"Other assignments to make Not Graded and move: {assignment_count}",
        f"Other unpublished items to move: {item_count}",
        f"Total planned actions: {len(plan.actions)}",
    ]
    if plan.issues:
        lines.extend(["", f"Items needing attention: {len(plan.issues)}"])
    lines.extend(["", "PLANNED ACTIONS", "=" * 72])
    lines.extend(action.description() for action in plan.actions)
    if plan.issues:
        lines.extend(["", "NEEDS ATTENTION", "=" * 72])
        lines.extend(f"• {issue}" for issue in plan.issues)
    return "\n".join(lines)


def execution_summary(report: dict[str, Any]) -> str:
    results = report.get("results", [])
    completed = [result for result in results if result.get("status") == "completed"]
    failed = [result for result in results if result.get("status") != "completed"]
    lines = [
        "RUN COMPLETE",
        "",
        f"Course: {report.get('course_name')}",
        f"Completed: {len(completed)}",
        f"Failed or skipped: {len(failed)}",
        "",
        "RESULTS",
        "=" * 72,
    ]
    for result in results:
        if result.get("status") == "completed":
            lines.append(f"✓ {result.get('title')} — {result.get('detail')}")
        else:
            lines.append(f"✗ {result.get('title')} — {result.get('error')}")
    return "\n".join(lines)


# Tkinter is imported late so the core can be tested without opening a window.
def launch_gui() -> None:
    import tkinter as tk
    from tkinter import messagebox, ttk
    from tkinter.scrolledtext import ScrolledText

    class CleanupWindow:
        def __init__(self, root: tk.Tk):
            self.root = root
            self.root.title(f"{APP_NAME} {APP_VERSION}")
            self.root.geometry("1050x760")
            self.root.minsize(900, 650)

            self.api: Optional[CanvasAPI] = None
            self.engine: Optional[CleanupEngine] = None
            self.courses: list[dict[str, Any]] = []
            self.course_by_display: dict[str, dict[str, Any]] = {}
            self.modules: list[dict[str, Any]] = []
            self.module_by_display: dict[str, dict[str, Any]] = {}
            self.current_plan: Optional[CleanupPlan] = None
            self.current_plan_path: Optional[Path] = None
            self.busy = False
            self.ui_queue: queue.Queue[tuple[str, Any]] = queue.Queue()

            self._build_styles(ttk)
            self._build_ui(tk, ttk, ScrolledText)
            self.root.after(100, self._drain_queue)

        def _build_styles(self, ttk_module: Any) -> None:
            style = ttk_module.Style()
            try:
                style.theme_use("vista" if sys.platform.startswith("win") else "clam")
            except Exception:
                pass
            style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
            style.configure("Section.TLabel", font=("Segoe UI", 11, "bold"))
            style.configure("Run.TButton", font=("Segoe UI", 10, "bold"))

        def _build_ui(self, tk_module: Any, ttk_module: Any, text_class: Any) -> None:
            outer = ttk_module.Frame(self.root, padding=16)
            outer.pack(fill="both", expand=True)
            outer.columnconfigure(1, weight=1)
            outer.rowconfigure(10, weight=1)

            ttk_module.Label(outer, text=APP_NAME, style="Title.TLabel").grid(
                row=0, column=0, columnspan=3, sticky="w"
            )
            ttk_module.Label(
                outer,
                text="Preview first. The token stays in memory and is never saved.",
            ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 14))

            ttk_module.Label(outer, text="Canvas address:").grid(row=2, column=0, sticky="w", pady=4)
            self.base_url = tk_module.StringVar(value=DEFAULT_CANVAS_URL)
            ttk_module.Entry(outer, textvariable=self.base_url).grid(
                row=2, column=1, sticky="ew", padx=(8, 8), pady=4
            )

            ttk_module.Label(outer, text="Access token:").grid(row=3, column=0, sticky="w", pady=4)
            self.token = tk_module.StringVar()
            ttk_module.Entry(outer, textvariable=self.token, show="•").grid(
                row=3, column=1, sticky="ew", padx=(8, 8), pady=4
            )
            self.connect_button = ttk_module.Button(outer, text="Connect", command=self.connect)
            self.connect_button.grid(row=2, column=2, rowspan=2, sticky="nsew", pady=4)

            ttk_module.Separator(outer).grid(row=4, column=0, columnspan=3, sticky="ew", pady=12)

            ttk_module.Label(outer, text="Course:").grid(row=5, column=0, sticky="w", pady=4)
            self.course_choice = tk_module.StringVar()
            self.course_combo = ttk_module.Combobox(
                outer, textvariable=self.course_choice, state="readonly", width=75
            )
            self.course_combo.grid(row=5, column=1, columnspan=2, sticky="ew", padx=(8, 0), pady=4)
            self.course_combo.bind("<<ComboboxSelected>>", lambda _event: self.load_modules())

            ttk_module.Label(outer, text="Unused module:").grid(row=6, column=0, sticky="w", pady=4)
            self.module_choice = tk_module.StringVar()
            self.module_combo = ttk_module.Combobox(
                outer, textvariable=self.module_choice, state="readonly", width=75
            )
            self.module_combo.grid(row=6, column=1, columnspan=2, sticky="ew", padx=(8, 0), pady=4)

            options = ttk_module.Frame(outer)
            options.grid(row=7, column=0, columnspan=3, sticky="ew", pady=(10, 4))
            self.convert_videos = tk_module.BooleanVar(value=True)
            self.archive_unpublished = tk_module.BooleanVar(value=True)
            ttk_module.Checkbutton(
                options,
                text="Convert video assignments to linked pages",
                variable=self.convert_videos,
            ).pack(side="left")
            ttk_module.Checkbutton(
                options,
                text="Move other unpublished content",
                variable=self.archive_unpublished,
            ).pack(side="left", padx=(24, 0))
            ttk_module.Label(options, text="Video title contains:").pack(side="left", padx=(24, 6))
            self.video_phrase = tk_module.StringVar(value="Video")
            ttk_module.Entry(options, textvariable=self.video_phrase, width=14).pack(side="left")

            safety = ttk_module.Frame(outer)
            safety.grid(row=8, column=0, columnspan=3, sticky="ew", pady=(4, 4))
            self.test_one_action = tk_module.BooleanVar(value=True)
            ttk_module.Checkbutton(
                safety,
                text="First-run test mode: preview and run only the first planned action",
                variable=self.test_one_action,
            ).pack(side="left")

            controls = ttk_module.Frame(outer)
            controls.grid(row=9, column=0, columnspan=3, sticky="ew", pady=(8, 8))
            self.preview_button = ttk_module.Button(
                controls, text="1. Preview Course", command=self.preview, state="disabled"
            )
            self.preview_button.pack(side="left")
            self.run_button = ttk_module.Button(
                controls,
                text="2. Run Approved Plan",
                command=self.run_plan,
                state="disabled",
                style="Run.TButton",
            )
            self.run_button.pack(side="left", padx=(10, 0))
            self.status = tk_module.StringVar(value="Enter the Canvas address and token, then connect.")
            ttk_module.Label(controls, textvariable=self.status).pack(side="right")

            self.output = text_class(outer, wrap="word", font=("Consolas", 9))
            self.output.grid(row=10, column=0, columnspan=3, sticky="nsew")
            self.output.insert("1.0", "No Canvas changes are made until you preview and confirm a plan.\n")
            self.output.configure(state="disabled")

        def _set_output(self, text: str) -> None:
            self.output.configure(state="normal")
            self.output.delete("1.0", "end")
            self.output.insert("1.0", text)
            self.output.configure(state="disabled")

        def _append_output(self, text: str) -> None:
            self.output.configure(state="normal")
            self.output.insert("end", text + "\n")
            self.output.see("end")
            self.output.configure(state="disabled")

        def _progress(self, message: str) -> None:
            self.ui_queue.put(("progress", message))

        def _set_busy(self, busy: bool) -> None:
            self.busy = busy
            self.connect_button.configure(state="disabled" if busy else "normal")
            if busy:
                self.preview_button.configure(state="disabled")
                self.run_button.configure(state="disabled")
            else:
                self.preview_button.configure(state="normal" if self.modules else "disabled")
                self.run_button.configure(state="normal" if self.current_plan else "disabled")

        def _async(self, task: Callable[[], Any], success: Callable[[Any], None]) -> None:
            if self.busy:
                return
            self._set_busy(True)

            def worker() -> None:
                try:
                    value = task()
                    self.ui_queue.put(("success", (success, value)))
                except Exception as exc:
                    self.ui_queue.put(("error", (exc, traceback.format_exc())))

            threading.Thread(target=worker, daemon=True).start()

        def _drain_queue(self) -> None:
            try:
                while True:
                    kind, payload = self.ui_queue.get_nowait()
                    if kind == "progress":
                        self.status.set(str(payload))
                    elif kind == "success":
                        callback, value = payload
                        self._set_busy(False)
                        callback(value)
                    elif kind == "error":
                        error, detail = payload
                        self._set_busy(False)
                        self.status.set("Stopped because Canvas returned an error.")
                        self._append_output(f"\nERROR: {error}")
                        save_json_report(
                            "error",
                            self.course_choice.get() or "canvas",
                            {"time": now_iso(), "error": str(error), "detail": detail},
                        )
                        messagebox.showerror(APP_NAME, str(error))
            except queue.Empty:
                pass
            self.root.after(100, self._drain_queue)

        def connect(self) -> None:
            try:
                api = CanvasAPI(self.base_url.get(), self.token.get())
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))
                return
            self.current_plan = None
            self.modules = []
            self.module_combo["values"] = []
            self.api = api
            self.engine = CleanupEngine(api, self._progress)
            self._set_output("Connecting to Canvas…\n")

            def task() -> list[dict[str, Any]]:
                assert self.engine is not None
                self.api.get("/users/self/profile")
                return self.engine.list_courses()

            self._async(task, self._connected)

        def _connected(self, courses: list[dict[str, Any]]) -> None:
            self.courses = courses
            self.course_by_display = {
                CleanupEngine.course_display_name(course): course for course in courses
            }
            values = list(self.course_by_display)
            self.course_combo["values"] = values
            self.status.set(f"Connected. Found {len(values)} courses.")
            self._set_output(
                "Connected successfully.\n\nSelect the course. Its modules will load automatically."
            )
            if len(values) == 1:
                self.course_choice.set(values[0])
                self.load_modules()

        def load_modules(self) -> None:
            if not self.engine:
                return
            course = self.course_by_display.get(self.course_choice.get())
            if not course:
                return
            self.current_plan = None
            self.run_button.configure(state="disabled")
            self._set_output(f"Loading modules for {course.get('name')}…\n")
            self._async(lambda: self.engine.list_modules(int(course["id"])), self._modules_loaded)

        def _modules_loaded(self, modules: list[dict[str, Any]]) -> None:
            self.modules = modules
            self.module_by_display = {}
            selected = ""
            for module in modules:
                state = "Published" if module.get("published") else "Unpublished"
                display = f"{module.get('name')}  —  {state}  (ID {module.get('id')})"
                self.module_by_display[display] = module
                if not selected and any(word in str(module.get("name", "")).casefold() for word in ("unused", "archive")):
                    selected = display
            values = list(self.module_by_display)
            self.module_combo["values"] = values
            if selected:
                self.module_choice.set(selected)
            elif values:
                self.module_choice.set(values[0])
            self.status.set(f"Loaded {len(modules)} modules. Choose the unused module, then preview.")
            self._set_output(
                "Modules loaded.\n\n"
                "Confirm the unused destination module carefully. The program will refuse to run if that module is published."
            )
            self.preview_button.configure(state="normal")

        def preview(self) -> None:
            if not self.engine:
                return
            course = self.course_by_display.get(self.course_choice.get())
            archive = self.module_by_display.get(self.module_choice.get())
            if not course or not archive:
                messagebox.showerror(APP_NAME, "Select both a course and the unused module.")
                return
            if not self.convert_videos.get() and not self.archive_unpublished.get():
                messagebox.showerror(APP_NAME, "Select at least one cleanup operation.")
                return
            self.current_plan = None
            self.run_button.configure(state="disabled")
            self._set_output("Scanning the course. Canvas has not been changed…\n")

            def task() -> CleanupPlan:
                plan = self.engine.build_plan(
                    course=course,
                    modules=self.modules,
                    archive_module=archive,
                    video_phrase=self.video_phrase.get(),
                    convert_videos=self.convert_videos.get(),
                    archive_unpublished=self.archive_unpublished.get(),
                )
                if self.test_one_action.get() and len(plan.actions) > 1:
                    total = len(plan.actions)
                    plan.actions = plan.actions[:1]
                    plan.issues.insert(
                        0,
                        f"TEST MODE: Showing only the first of {total} planned actions. "
                        "After verifying it in Canvas, turn off test mode and preview again.",
                    )
                return plan

            self._async(task, self._preview_ready)

        def _preview_ready(self, plan: CleanupPlan) -> None:
            self.current_plan = plan
            self.current_plan_path = save_json_report("preview", plan.course_name, plan.to_dict())
            self._set_output(plan_summary(plan))
            blocking = any(issue.startswith("BLOCKING:") for issue in plan.issues)
            self.run_button.configure(
                state="normal" if plan.actions and not blocking else "disabled"
            )
            self.status.set(
                f"Preview complete: {len(plan.actions)} actions. Backup saved before any changes."
            )

        def run_plan(self) -> None:
            if not self.current_plan or not self.engine:
                return
            plan = self.current_plan
            answer = messagebox.askyesno(
                "Run Canvas cleanup?",
                f"Course: {plan.course_name}\n\n"
                f"Planned actions: {len(plan.actions)}\n"
                f"Destination: {plan.archive_module_name}\n\n"
                "The preview and all captured video links have already been saved. Continue?",
                icon="warning",
            )
            if not answer:
                return
            self._set_output(plan_summary(plan) + "\n\nRUNNING…\n")
            self._async(lambda: self.engine.execute_plan(plan), self._run_complete)

        def _run_complete(self, report: dict[str, Any]) -> None:
            path = save_json_report("results", str(report.get("course_name")), report)
            summary = execution_summary(report)
            self._set_output(summary)
            failures = sum(result.get("status") != "completed" for result in report.get("results", []))
            self.current_plan = None
            self.run_button.configure(state="disabled")
            self.status.set(f"Finished. Results saved in {path.parent.name}.")
            if failures:
                messagebox.showwarning(
                    APP_NAME,
                    f"Cleanup finished with {failures} item(s) needing attention. Review the results shown in the window.",
                )
            else:
                messagebox.showinfo(APP_NAME, "Cleanup finished successfully. Review Canvas, then preview again if needed.")

    root = tk.Tk()
    CleanupWindow(root)
    root.mainloop()


if __name__ == "__main__":
    launch_gui()
